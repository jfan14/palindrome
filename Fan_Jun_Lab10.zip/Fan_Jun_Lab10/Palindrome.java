import java.util.Scanner;
public class Palindrome {
	
	public static boolean testPalindrome(String testCase) {
		testCase = testCase.toLowerCase();
		int length = testCase.length();
		System.out.println(testCase);
		int counter1=0;
		int counter2=length;
		if(length != 1 && length != 0) {
			if(testCase.charAt(counter1)==' ') {
				counter1++;
				testCase = testCase.substring(counter1, counter2);
				return testPalindrome(testCase);
			}
			if(testCase.charAt(counter2-1)==' ') {
				counter2--;
				testCase = testCase.substring(counter1, counter2);
				return testPalindrome(testCase);
			}
			if(testCase.charAt(counter1)== testCase.charAt(counter2-1)){
				counter1++;
				counter2--;
				testCase = testCase.substring(counter1, counter2);
				return testPalindrome(testCase);
			}else {
				return false;
			}
		} else{
			return true;
		}
			
		
		
	}
	
	public static void main(String [] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter a String: ");
		String input = scan.nextLine();
		if(testPalindrome(input) == true) {
			System.out.println("This is palindrome");
		}
		else{
			System.out.println("This is not palindrome");
		}
		
	}
}
